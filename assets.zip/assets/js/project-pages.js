
(()=>{
 const examples={
 compatibility:{question:'Does Demo Dock A support two displays on Demo Laptop B?',route:'Exact product ID + graph + text',evidence:[['[S1] Catalog record','Demo Dock A and Demo Laptop B resolve to exact product IDs.'],['[S2] Compatibility record','A source-backed relationship lists dual-display support.'],['[S3] Manual excerpt','The connection and display requirements are preserved.']],answer:'Confirm support for the named configuration, include the manual’s connection requirements, and cite [S2] and [S3].'},
 visual:{question:'Which accessory has this connector shape?',route:'Image embeddings + catalog identity + text',evidence:[['[S1] Product image','Visual retrieval finds an accessory with a similar connector.'],['[S2] Catalog metadata','The image links to a specific product and model number.'],['[S3] Specification record','The documented connector type can be checked against the candidate.']],answer:'Show the candidate image and product record, then ask the customer to confirm the model. Appearance alone does not establish electrical or device compatibility.'},
 missing:{question:'Will this charger work with my laptop?',route:'Clarification before recommendation',evidence:[['Missing product identity','The laptop model and charger part number are not provided.'],['Insufficient compatibility evidence','A similar-looking connector does not establish power or protocol support.'],['Next useful input','Request the exact model numbers or a readable product-label image.']],answer:'Ask for the laptop model and charger part number. Avoid presenting an unsupported compatibility recommendation as a fact.'}
 };
 document.querySelectorAll('[data-case]').forEach(button=>button.addEventListener('click',()=>{
  const item=examples[button.dataset.case];
  document.querySelectorAll('[data-case]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  document.getElementById('demo-question').textContent=item.question;document.getElementById('demo-route').textContent=item.route;document.getElementById('demo-answer').textContent=item.answer;
  const list=document.getElementById('demo-evidence');list.replaceChildren();item.evidence.forEach(([title,body])=>{const li=document.createElement('li'),b=document.createElement('b');b.textContent=title;li.append(b,document.createTextNode(body));list.append(li)});
 }));
 let copyTimer;
 document.querySelectorAll('.copy').forEach(button=>button.addEventListener('click',async()=>{
  const text=button.closest('.codebox').querySelector('code').textContent;const status=document.querySelector('.copy-status');
  try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text)}else{const input=document.createElement('textarea');input.value=text;input.style.position='fixed';input.style.opacity='0';document.body.append(input);input.select();const ok=document.execCommand('copy');input.remove();if(!ok)throw Error('copy');button.focus()}status.textContent='Code copied.';button.textContent='Copied';setTimeout(()=>button.textContent='Copy',1800)}catch(e){status.textContent='Select the code and copy it with your keyboard.'}
  clearTimeout(copyTimer);copyTimer=setTimeout(()=>status.textContent='',3500);
 }));

 const search=document.getElementById('project-search');
 if(search){
  const query=document.getElementById('query'), cards=[...document.querySelectorAll('#sidebar-projects article')];
  search.addEventListener('submit',e=>e.preventDefault());
  query.addEventListener('input',()=>{
   const q=query.value.trim().toLowerCase();let count=0;
   cards.forEach(card=>{const show=!q||(card.dataset.projectTitle+' '+card.textContent).toLowerCase().includes(q);card.hidden=!show;if(show)count++});
   document.getElementById('search-count').textContent=q?count+' project'+(count===1?'':'s')+' found.':'';
  });
 }
 const toggle=document.querySelector('#sidebar .toggle');
 if(toggle){toggle.setAttribute('aria-label','Toggle project navigation');toggle.setAttribute('aria-controls','sidebar');
  const sync=()=>toggle.setAttribute('aria-expanded',String(!document.getElementById('sidebar').classList.contains('inactive')));
  new MutationObserver(sync).observe(document.getElementById('sidebar'),{attributes:true,attributeFilter:['class']});sync();}
})();
